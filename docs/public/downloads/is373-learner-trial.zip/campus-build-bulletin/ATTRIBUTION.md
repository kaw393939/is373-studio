# Attribution and provenance

Fresh source from the updated Content Desk teaching ZIP, SHA-256 `dbed84065af697182dd8f6202cb25150bc2542da9ab1595bbaf499a395c805c5`. The source and this trial's modifications were produced with AI-agent assistance.

Carried the round-1 synthetic campus fixture case into a fresh extraction; retained the updated source-preservation helper and classroom Python guidance; extended the focused acceptance check to inspect the new helper/link. Added actual local route receipts and separate learner technical records.

This is a fictional student scenario, not an actual NJIT student submission. All fixtures are fictional classroom content. No real peer, teammate, customer interview, GitHub CI run or hosted deployment is represented.
