# Round 2 · shared ETL technical record

Actual technical case, not actual group work: three authored synthetic campus documents create two drafts and three source records. A second import adds no drafts and skips all three sources. The pipeline retains source provenance and waits for a person to publish.

Compared one draft per source with normalized deduplication while retaining sources; chose the latter (SPEC.md). The focused bulletin check verifies both source IDs, private-before-publication behavior, repeated import and the new visible authored-revision path. The full source suite also exercises invalid/unpermitted inputs, conflicts and transaction rollback.

One automated trial runner made these changes with agent assistance. No real partner, contribution split or cross-review exists. A genuine group still supplies named work, actual review, a resulting change/retest and all required course evidence. No group grade is assigned.
