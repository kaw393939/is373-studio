# Campus Build Bulletin · small delivery promise

**Fictional learner scenario; actual local code and checks.** An imagined 20-year-old NJIT student has working server-course experience and limited time. No real club, customer interview or student participant is represented.

## Person and useful result

A student wants a small place to discover practice sessions and share a short notice. A club editor wants to check a notice before it is public. The finished promise is one account → draft → review → published-notice path plus an import of three bundled synthetic notices.

## Two approaches

| Choice | Benefit | Cost / risk |
| --- | --- | --- |
| A: publish immediately, remove later | Fastest path for the author | Visitors can see an unchecked notice |
| B: private draft, editor publishes | Clear review gate; small permission model | Requires the editor to finish the path |

Choose B. This is a design rationale, not evidence that a real audience preferred it. Keep one content type, three categories and plain text. The original Content Desk implements the same review gate; reuse it and customize the campus task rather than inventing a new identity system.

## Two ETL approaches

A: load each source as its own draft. B: normalize spacing/case for duplicate matching, keep one content draft and attach distinct source records. Choose B: two fixture documents repeat the same Build Night notice, so there should be two drafts from three documents.

## Checkable stories

- As a member, I save a notice privately and can edit my own draft.
- As another member or visitor, I cannot read or overwrite that private draft.
- As an editor, I read the notice before publication; visitors can then read it.
- As an editor, I import the three permitted fixtures twice without creating duplicate drafts or losing provenance.

## Out of scope

Real NJIT events, real people, live feeds, AI APIs, actual external deployment, email recovery, a fully featured CMS and claims of a real team. Existing baseline server/security tests remain part of the local check.
