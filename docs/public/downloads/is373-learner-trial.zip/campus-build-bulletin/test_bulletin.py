"""One focused acceptance check added for the learner's campus bulletin case."""
from test_app import app, login, post
from store import connect


def test_build_night_bulletin_retains_both_sources_and_waits_for_review(app):
    editor=app.test_client()
    login(editor,'admin')
    first=post(editor,'/pipeline',form='/pipeline')
    assert b'2</b> drafts added' in first.data
    with connect(app.config['DATABASE']) as db:
        bulletin=db.execute("SELECT id,status FROM articles WHERE title=?",('Build Night: bring one small demo',)).fetchone()
        sources=db.execute('SELECT source_key FROM sources WHERE article_id=? ORDER BY source_key',(bulletin['id'],)).fetchall()
    assert bulletin['status']=='draft'
    assert [row['source_key'] for row in sources]==['build-night-original','build-night-reminder']
    visitor=app.test_client()
    location=f"/articles/{bulletin['id']}"
    assert visitor.get(location).status_code==404
    imported=editor.get(location)
    assert b'write a revised draft' in imported.data
    assert b'href="/drafts/new"' in imported.data
    second=post(editor,'/pipeline',form='/pipeline')
    assert b'0</b> drafts added' in second.data and b'3</b> already imported' in second.data
    assert post(editor,location+'/publish',form=location).status_code==302
    published=visitor.get(location)
    assert published.status_code==200
    assert b'Build Night: bring one small demo' in published.data
    assert b'build-night-reminder' in published.data
