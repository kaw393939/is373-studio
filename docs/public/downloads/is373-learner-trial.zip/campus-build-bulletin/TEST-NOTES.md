# Actual technical checks · November 3, 2026

- Python 3.14.7, Flask 3.1.3, Flask-WTF 1.2.2, pytest 9.2.0.
- `python -m pytest -q docs/public/examples/content-desk/test_app.py`: **40 passed in 8.36s** during authoring. Subsequent verified command/result may be recorded in the course review.
- Real file-backed SQLite test databases live in pytest's temporary directory, not the website source or download. Test clients exercise actual routes, database writes, password verification, signed cookies and CSRF protection.
- End-to-end member draft → admin review/publish → anonymous read passed.
- Direct member/admin and cross-member requests are denied. Role changes and expired/revoked sessions are checked against the server.
- Login/logout, invalid registration, duplicate username, bad passwords, SQL-shaped input, five-attempt login throttle and cookie/header flags passed.
- Missing CSRF tokens are denied on every mutating route. User HTML renders as escaped plain text.
- ETL valid/empty/invalid/duplicate/changed/unpermitted sources, retained provenance, a repeated import and transaction rollback passed.
- The restart check creates a new application instance against the same on-disk database and signing key, then verifies persisted draft/session/login behavior. It is an integration check, not a production deployment exercise.

## Limits kept visible

The code was created with agent assistance and checked with automated tests. No real human student or peer participated. No grade, customer validation or proven equal team effort is claimed. Manual browser/mobile review is a separate check; the automated result alone does not establish usability or accessibility compliance.

The app is a bounded local reference, not a hardened public service. Login has a small local throttle; signup remains local-only without a public anti-abuse service. Profile maintenance covers a display-name change. No email/password recovery, MFA, account deletion, content-version history, real-world source validation or paid AI integration is included.
