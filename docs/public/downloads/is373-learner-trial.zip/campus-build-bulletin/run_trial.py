"""Actual local route/database exercise; no browser or human review is implied."""
import json,os,re
from pathlib import Path
from app import create_app
from store import connect

ROOT=Path(__file__).resolve().parents[2]
os.environ['CONTENT_DESK_DATA']=str(ROOT/'runtime')
credentials={}
for line in (ROOT/'receipts/local-seed.txt').read_text().splitlines():
    if ' password: ' in line:
        name,password=line.split(' password: ',1)
        credentials[name]=password
app=create_app()

def token(client,path):
    result=client.get(path)
    return re.search(rb'name="csrf_token" value="([^"]+)"',result.data).group(1).decode()

def post(client,path,data=None,form='/login'):
    fields=dict(data or {});fields['csrf_token']=token(client,form)
    return client.post(path,data=fields)

def login(client,name):
    return post(client,'/login',{'username':name,'password':credentials[name]})

member,admin,visitor=app.test_client(),app.test_client(),app.test_client()
receipt={'kind':'Actual local Flask route/SQLite exercise; browser and human review are separate','steps':[]}
def record(task,response,**extra):
    receipt['steps'].append({'task':task,'status':response.status_code,**extra})
record('Member login',login(member,'member'))
new=post(member,'/drafts/new',{'title':'Bring a tiny working feature','body':'This fictional practice session asks each student to bring one working feature, show a check and ask a classmate to try the task.','category':'Learning'},form='/drafts/new')
location=new.headers['Location'];record('Save a private member notice',new,location=location)
record('Visitor direct request to private notice',visitor.get(location))
record('Admin login',login(admin,'admin'))
first=post(admin,'/pipeline',form='/pipeline');record('Import three new synthetic documents',first,expected_report='2 drafts,1 additional source,0 already imported',observed_report=re.search(rb'<p><b>.*?</p>',first.data).group(0).decode())
second=post(admin,'/pipeline',form='/pipeline');record('Repeat import',second,expected_report='0 drafts,0 additional sources,3 already imported',observed_report=re.search(rb'<p><b>.*?</p>',second.data).group(0).decode())
with connect(app.config['DATABASE']) as db:
    imported=db.execute("SELECT id FROM articles WHERE title='Build Night: bring one small demo'").fetchone()['id']
    draft_count=db.execute("SELECT count(*) FROM articles WHERE status='draft'").fetchone()[0]
record('Try to edit a source-linked imported draft',admin.get(f'/drafts/{imported}/edit'),expected='409 conflict; immutable imported source text')
imported_location=f'/articles/{imported}'
imported_page=admin.get(imported_location)
helper_present=b'write a revised draft' in imported_page.data
record('Imported-draft helper is visible',imported_page,helper_present=helper_present)
assert helper_present
helper_destination='/drafts/new'
record('Follow source-preserving revision link',admin.get(helper_destination))
revision=post(admin,helper_destination,{'title':'Build Night: clearer preparation instructions','body':'This fictional Build Night asks each participant to bring one working feature and one passing check. Prepare a two-minute demo and one question for a classmate.','category':'Learning'},form=helper_destination)
revised_location=revision.headers['Location']
record('Save a separate authored revision',revision,location=revised_location)
record('Review the authored revision',admin.get(revised_location))
record('Publish the authored revision',post(admin,revised_location+'/publish',form=revised_location))
record('Visitor reads the authored revision',visitor.get(revised_location))
record('Admin publishes authored member notice',post(admin,location+'/publish',form=location))
record('Visitor reads the now-published notice',visitor.get(location))
record('Member logout',post(member,'/logout',form='/dashboard'))
record('Logged-out private dashboard',member.get('/dashboard'))
restarted=create_app()
with connect(restarted.config['DATABASE']) as db:
    receipt['persisted_after_new_app_instance']={'articles':db.execute('SELECT count(*) FROM articles').fetchone()[0], 'sources':db.execute('SELECT count(*) FROM sources').fetchone()[0],'published':db.execute("SELECT count(*) FROM articles WHERE status='published'").fetchone()[0]}
receipt['limits']=['No real peer or team','No production deployment or remote CI','Fresh app-instance persistence test, not hosted reboot exercise']
(ROOT/'receipts/local-workflow.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
